#include<iostream>
#include<stdlib.h>
#include<windows.h>
using namespace std;

void validar();

void gotoxy(int x,int y){
HANDLE hcon;
hcon = GetStdHandle(STD_OUTPUT_HANDLE);
COORD dwPos;
dwPos.X = x;
dwPos.Y= y;
SetConsoleCursorPosition(hcon,dwPos);
}

class cola{
private:
int inicio,fin;
int dato[10];

public:
           cola();
           int lleno();
           int vacio();
               void llenar( );
               void consultar_inicio();
               void consultar_final();
               void mostrar_cola();
               void eliminar();
               void gotoxy(int ,int );




};

void cola::gotoxy(int x,int y){
HANDLE hcon;
hcon = GetStdHandle(STD_OUTPUT_HANDLE);
COORD dwPos;
dwPos.X = x;
dwPos.Y= y;
SetConsoleCursorPosition(hcon,dwPos);
}

cola::cola(){
fin=-1;
inicio=0;
}
 void cola::llenar(){
  int x;
if(lleno()==0){
fin ++;
gotoxy(52,22);
cout<<"Ingrese dato: ";
        cin>>x;
  dato[fin]=x;

}
 }



bool validar(char []);
//char numero='\x0';
int x=0;
void validar() {
    system("cls");
  char buffer[256];
   cout<<"ingrese numero"<<endl;
   cin>>buffer;
   if(validar(buffer)){
      x=atoi(buffer);
       cout<< x+2;
   }
  // cout<<int(numero);
 system("pause>>cls");
}
bool validar(char numero[]){
bool ban=false;
if((int(numero[0])>=48) && (int(numero[0])<=57 )){
       ban=true;
}
return ban;
}



void cola::consultar_inicio(){
if(vacio()==0){
        system("cls");
gotoxy(20,10);
cout<<"\tEL inicio es:      "<<char(186)<<" "<<dato[0]<<" "<<char(186)<<endl;
cola::gotoxy(43,9);
printf("%c%c%c%c%c", 201,205,205,205,187);
cola::gotoxy(43,11);
printf("%c%c%c%c%c", 204,205,205,205,185);
cout<<"\n\n";
system("pause");
}
}


void cola::consultar_final(){
if(vacio()==0){
        system("cls");
        gotoxy(20,10);
        cout<<"\tEL final es:       "<<char(186)<<" "<<dato[fin]<<" "<<char(186)<<endl;
        cola::gotoxy(43,9);
        printf("%c%c%c%c%c", 201,205,205,205,187);
        cola::gotoxy(43,11);
        printf("%c%c%c%c%c", 204,205,205,205,185);
        cout<<"\n\n";
        system("pause");
}
}


void cola::mostrar_cola(){
if(vacio()==0){
system("cls");
printf("\n\n\t        %c%c%c%c%c \n", 201,205,205,205,187);
    for(int i=fin;i>=0;i--){
       if(dato[i]!=-1){
        printf("\t\t%c ", 186);cout<<dato[i]; printf(" %c\n", 186);
            printf("\t\t%c%c%c%c%c\n", 204,205,205,205,185);
            }
    }


}


}


void cola::eliminar(){
if(vacio()==0){
for(int i=0;i<=fin;i++){
dato[i]=dato[i+1];
}
dato[fin]=-1;
fin--;
}
}


int cola::lleno(){
if(fin==9){
cout<<"LA COLA ESTA LLENA"<<endl;
system("pause");
return 1;
}else{
return 0;
}
}
int cola::vacio(){
if(fin==-1){
cout<<"LA COLA ESTA VACIA"<<endl;
system("pause");
return 1;
} else{
return 0;
}
}




int main(){
   int dato;
    int opcion;
    cola c;
do{
system("cls");
    c.mostrar_cola();
    cout<<""<<endl;
    gotoxy(52,4);
    cout<<"Menu"<<endl;
    gotoxy(52,7);
    cout<<"[1]Encolar(push)"<<endl;
    gotoxy(52,9);
    cout<<"[2]Mostrar inicio"<<endl;
    gotoxy(52,11);
    cout<<"[3]Mostrar fin"<<endl;
    gotoxy(52,13);
    cout<<"[4]Des-Encolar(pop)"<<endl;
    gotoxy(52,15);
    cout<<"[5]Mostrar cola"<<endl;
    gotoxy(52,19);
    cout<<"[6].Salir"<<endl;
    gotoxy(52,21);
    cout<<"Opcion: ";
    cin>>opcion;
    switch(opcion){
    case 1:
            c.llenar();
            break;
    case 2: c.consultar_inicio();
        break;
case 3: c.consultar_final();
        break;
    case 4: c.eliminar();
          break;
case 5: c.mostrar_cola();
         break;

   }

       }while(opcion!=6);
   }
